LotTrack - Written to track lot numbers from an assembly machine.  This machine has two lot numbers per part.

HARDWARE:
1. Siemens PLC.  Initially the program was tested on an S7-200 micro plc using the PC's serial port and a PPI cable, but final debug was done with a CPU317 over ethernet through a CP 343 module.  NOTE: If you want to connect this to an S7-200 again, change the DB read to 1.
2. The program was written on an IBM Thinkpad laptop.  For the final installation, it was installed on a Dell.  Both are running Windows XP with service pack 2.

DATA COMMUNICATION THEORY:
The DB in the PLC contains 5 fields.
PC_Count - 2 bytes (integer)
PLC_Count - 2 bytes (integer)
Model - Model of part currently being assembled on the machine.
Front_Lot - The first of two lot numbers the PC must record.
Rear_Lot - The second of two lot numbers the PC must record.
	When the PLC is ready for the PC to record information, the PLC increments the PLC_Count field.  The PC is reading all 5 fields every 1.5 seconds.  When the PC detects that PC_Count <> PLC_Count, then it records the data, and then writes the value of PLC_Count into PC_Count.  The ladder logic in the PLC only checks before writing new lot information that the two counts are equal.  If they are equal, it writes the new information and then increments PLC_Count.  If they are not equal, then it faults out.

INSTALLATION:
Installing the software for this project is quite straightforward.
1. Install MySQL.  Version 4.1.12 was used, but most any later version should work.  Install with the default options works well.
2. Install MyODBC.  Version 3.51.11 was used.
3. Use Visual Basic Package & Deployment Wizard to generate an install for this program.  There are a couple changes to make here:
	a. If installing for XP, do NOT install the MDAC components.  There really is no danger if you do include MDAC, but it will generate an error during the install, which may confuse or alarm an installer.
	b. Specify that libnodave.dll should be installed in the Win\Sys directory (Windows\System32 for XP).

NOTES:
1. As stated above, this was written initially and tested with an S7-200.  Final debug was done over ethernet.  I did NOT go back and test with the serial port and S7-200, so there may be some minor things that don't work there.
2. I did NOT write this so that the user could select between serial or ethernet.  It is an either/or depending on which form is included in the project.  Include fPlcConnEther for ethernet or fPlcConnSerial for a serial connection.  It would not require major changes to allow a user to select between the two, but it was unnecessary in this case, so I didn't do it.

LICENSING:
I, Bryan Rubingh, owner of Rube Automation, am the original author of this VB code.  Many thanks to those who have worked to make libnodave available.  You are free to use this code in whatever way you see fit.  I make absolutely no guarantees, promises, or any other indication that it will serve your intended purpose.  We'd be happy to discuss your automation needs.  We've been in business for over 10 years now serving the manufacturing industry with automated solutions.  We are happy to work by time and material or by quoted pricing.  As of this writing, we can be contacted at:
	Rube Automation
	2344 Gilbert Rd.
	Lansing, MI 48911
	Ph: 517-694-0294
	b.rubingh@rubeautomation.com